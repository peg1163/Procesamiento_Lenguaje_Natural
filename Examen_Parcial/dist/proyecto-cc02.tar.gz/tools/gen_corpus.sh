#!/usr/bin/env bash
# Genera un corpus sintético verificable por SEED+SALT.
# Requiere: bash + python (stdlib). No usa paquetes extra.
set -euo pipefail

: "${OUT:=out}"
: "${SEED:=1337}"
: "${SALT:=CC02}"

mkdir -p "$OUT"
RAW="$OUT/corpus_raw.txt"
META="$OUT/corpus_meta.json"
SUM="$OUT/CORPUS_SHA256.txt"

# --- Generación determinista (dos tareas: patrones y sumas con acarreo) ---
python - "$RAW" "$META" "$SUM" << 'PY'
import os, sys, random, hashlib, json, io, math
raw, meta, sumf = sys.argv[1], sys.argv[2], sys.argv[3]
SEED = int(os.getenv("SEED","1337"))
SALT = os.getenv("SALT","CC02")

rnd = random.Random(SEED)
lines = []

# 1) Patrones con () y abc (longitudes variables)
for _ in range(2000):
    k = rnd.randint(5, 40)
    lines.append(''.join(rnd.choice('abc()') for _ in range(k)))

# 2) Sumas con acarreo: "A+B=" (sin respuesta; next-char)
for _ in range(2000):
    a = rnd.randint(0, 9999)
    b = rnd.randint(0, 9999)
    lines.append(f"{a}+{b}=")

# Escribir corpus (LF/UTF-8)
with io.open(raw, "w", encoding="utf-8", newline="\n") as f:
    f.write("\n".join(lines) + "\n")

# Hash verificable (corpus bytes + SALT)
with open(raw, "rb") as f:
    h = hashlib.sha256(f.read() + SALT.encode("utf-8")).hexdigest()

with open(sumf, "w", encoding="utf-8", newline="\n") as f:
    f.write(h + "\n")

with open(meta, "w", encoding="utf-8", newline="\n") as f:
    json.dump({"seed": SEED, "salt": SALT, "sha256": h, "n_lines": len(lines)}, f, indent=2)
print("OK")
PY

# --- Modo verificación: regenera y compara SHA ---
if [[ "${1:-}" == "--verify" ]]; then
  echo "[verify] verificando corpus por SEED+SALT…"
  H1="$(cat "$SUM")"
  rm -f "$RAW" "$META" "$SUM"
  SEED="$SEED" SALT="$SALT" OUT="$OUT" bash "$0"
  H2="$(cat "$SUM")"
  if [[ "$H1" == "$H2" ]]; then
    echo "[verify] OK: hashes coinciden ($H1)"
  else
    echo "[verify] ERROR: hash no coincide" >&2
    echo "  esperado: $H1" >&2
    echo "  obtenido: $H2" >&2
    exit 1
  fi
fi
